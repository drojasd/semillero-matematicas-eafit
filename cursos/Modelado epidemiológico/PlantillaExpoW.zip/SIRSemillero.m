function sol = SIRSemillero(pars,domain,in)

    time = domain(1):domain(2);
    M=zeros(4,length(time));
    M(1,1)=pars(1);  % S
    M(2,1)=pars(2);  % I
    M(3,1)=pars(3);  % R
    beta=pars(4);
    gamma=pars(5);
    alpha=pars(6);
    init = round(pars(7));
    fend = round(pars(8));
    pvac = pars(9);
    
    vcCost = in.vccCost;
    ICost = in.ICost;
    sim_time = 1:(length(time)-1);
    vacc = zeros(1, length(time));  % Initialize vaccination array
    if init > fend
        aux = init;
        init = fend;
        fend = aux;
    end
    vacc(init:fend) = pvac;
    
    for k = sim_time
        N = sum(M(1:3,k));
        M(1,k+1) = M(1,k)*(1-M(2,k)/N*beta)*(1-vacc(k)) + alpha*M(3,k);
        M(2,k+1) = M(1,k)*M(2,k)/N*beta*(1-vacc(k)) + (1-gamma)*M(2,k);
        M(3,k+1) = (1-alpha)*M(3,k) + M(1,k)*vacc(k) + gamma*M(2,k);
        M(4,k+1) = M(4,k) + M(1,k)*vacc(k)*vcCost + M(1,k)*M(2,k)/N*beta*(1-vacc(k))*ICost;
    end
    
    sol=struct();
    sol.x=time;
    sol.y=M;

end
function sol = SIRSemillero(pars,domain,in)
%SIRSEMILLERO  SIR discreto con pérdida de inmunidad y, opcionalmente, vacunación.
%   pars = [S0 I0 R0 beta gamma alpha]                      (sin vacunación)
%   pars = [S0 I0 R0 beta gamma alpha init fend pvac]       (vacuna una fracción pvac de S
%                                                            entre los pasos init y fend)
%   in.vccCost, in.ICost: costos por vacunado y por infectado (0 si no se dan).
%   Probabilidad de contagio exponencial: P(k) = 1 - exp(-beta*I(k)/N).
%   Filas de sol.y: 1 S, 2 I, 3 R, 4 costo acumulado.
    if nargin < 3 || ~isstruct(in), in = struct(); end
    time = domain(1):domain(2);
    M=zeros(4,length(time));
    M(1,1)=pars(1);  % S
    M(2,1)=pars(2);  % I
    M(3,1)=pars(3);  % R
    beta=pars(4);
    gamma=pars(5);
    alpha=pars(6);
    vacc = zeros(1, length(time));  % fracción de S vacunada en cada paso
    if numel(pars) >= 9
        init = round(pars(7));
        fend = round(pars(8));
        pvac = pars(9);
        if init > fend
            aux = init;
            init = fend;
            fend = aux;
        end
        vacc(max(init,1):min(fend,length(time))) = pvac;
    end
    vcCost = 0; ICost = 0;
    if isfield(in, 'vccCost'), vcCost = in.vccCost; end
    if isfield(in, 'ICost'), ICost = in.ICost; end
    for k = 1:(length(time)-1)
        N = sum(M(1:3,k));
        P = -expm1(-beta*M(2,k)/N);   % probabilidad de contagio P(k) = 1 - exp(-beta*I(k)/N)
        M(1,k+1) = M(1,k)*(1-P)*(1-vacc(k)) + alpha*M(3,k);
        M(2,k+1) = M(1,k)*P*(1-vacc(k)) + (1-gamma)*M(2,k);
        M(3,k+1) = (1-alpha)*M(3,k) + M(1,k)*vacc(k) + gamma*M(2,k);
        M(4,k+1) = M(4,k) + M(1,k)*vacc(k)*vcCost + M(1,k)*P*(1-vacc(k))*ICost;
    end
    sol=struct();
    sol.x=time;
    sol.y=M;
end

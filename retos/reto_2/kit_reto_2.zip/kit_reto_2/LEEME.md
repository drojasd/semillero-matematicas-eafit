# Kit del reto R2 · SIR discreto con pérdida de inmunidad

Semillero de Investigación en Matemáticas · EAFIT

> **Versión relanzada el 25 de octubre de 2026.** El modelo ahora usa la probabilidad de contagio
> exponencial `P(k) = 1 − exp(−β·I(k)/N)`; datos y sello son nuevos. Si descargaste un kit antes,
> bórralo y usa este: las entregas hechas con el anterior no son válidas.

## Antes de empezar

1. Instala la toolbox **GSUA-CSB v1.13** en MATLAB: abre con doble clic el archivo
   `GSUA-CSB.mltbx` que la coordinación compartió por WhatsApp. Si prefieres Python, el paquete
   `gsua_csb` está en <https://github.com/drojasd/GSUA-CSB>, en la carpeta `python/`.
2. Descomprime este kit y abre la carpeta en MATLAB como carpeta actual.

## Qué hay aquí

| Carpeta | Para qué |
|---|---|
| `hands_on/` | El guion paso a paso (`plantilla_estudiante.m` / `.mlx`), el modelo y los datos en el formato del hands-on |
| `retos/reto_2/` | El enunciado (`reto_2.json`, `README.md`), los mismos datos en formato de reto y la **plantilla de entrega** |
| `retos/` | Las reglas (`README.md`), los modelos, las funciones para llenar la entrega y el calificador |

## El reto en tres pasos

1. **Explora con el guion.** `hands_on/plantilla_estudiante.m` recorre el flujo de la toolbox:
   `gsua_dataprep` → `gsua_pe` → `gsua_ia`. Elige un caso, ajústalo y mira qué parámetros quedan
   bien determinados.
2. **Decide y estima.** Para cada caso (`c1` … `c6`) y cada parámetro, responde: ¿es
   identificable?, ¿cuánto vale?, ¿cuál es su intervalo de confianza al 95 %? El módulo 5 del curso
   (<https://drojasd.github.io/GSUA-CSB/course/modulo-05-matlab.html>) muestra cómo obtener un
   conjunto de estimaciones repitiendo el ajuste.
3. **Entrega.** Llena `retos/reto_2/entrega_plantilla.json` con `llenar_entrega` y guárdala con
   `guardar_entrega` (ejemplos en `retos/README.md`). Pon el nombre del equipo y sus integrantes,
   y envía el archivo `.json` **por WhatsApp a la coordinación** (mensaje directo, no al grupo:
   las demás entregas no deben verse antes de calificar).

Cómo se califica: `retos/README.md`. Gana la **menor penalización**. Cuenta tanto acertar como
ser honesto sobre lo que no se puede recuperar.
